<script>
import axios from 'axios';
import CreateRecipe from '../components/CreateRecipe.vue'
axios.defaults.baseURL = "http://localhost:3005"
// Код компонента
export default {
	components: {
		CreateRecipe
	},
	data() {
		return {
			dishes: [],
			cooked: [],
			title: '',
			preparation: '',
			image: '',
			timeToCook: 10
		};
	},

	mounted() {
		this.loadDishes()
		this.loadCooking()
	},

	computed:{
		dishCount(){
			return this.dishes.length
		},
		dishReadyCount(){
			return this.cooked.length
		}
	},

	methods: {
		async loadDishes() {
			let response = await axios.get('/dishes');
			this.dishes = response.data
		},
		async loadCooking() {
			let response = await axios.get('/cooking');
			this.cooked = response.data
		},
		async cooking(id) {
			let response = await axios.post('/cooking/cook', {
				id: id
			});
			this.loadCooking()
		},
		async createDish() {
			await axios.post('/dishes', {
				title: this.title,
				preparation: this.preparation,
				timeToCook: this.timeToCook,
				image: this.image
			});
			this.loadDishes();
		},
		minuteEnding(num){
			if (num == 1) {
				return 'а';
			}
			else if (1 < num && num <= 4) {
				return 'ы';
			}
			else {
				return '';
			}
	}
	},
};
</script>

<template>
<!-- Image and text -->
<div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
    Dropdown button
  </button>
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="#">Action</a></li>
    <li><a class="dropdown-item" href="#">Another action</a></li>
    <li><a class="dropdown-item" href="#">Something else here</a></li>
  </ul>
</div>
	<br>
	<div class="container">
		<form @submit.prevent="createDish" class="mb-3">
			<div class="mb-3">   
				<label for="title" class="form-label">Название рецепта</label>
				<input v-model="title" type="text" class="form-control" id="title" placeholder="Пицца с ананасами">
			</div>
			<div class="mb-3">
				<label for="img" class="form-label">Изображение блюда</label>
				<input v-model="image" type="text" class="form-control" id="img" placeholder="">
			</div>
			<div class="mb-3">
				<label for="preparation" class="form-label">Рецепт</label>
				<textarea v-model="preparation" class="form-control" id="preparation" rows="3" placeholder="Положите ананас на пиццу. Вуаля!"></textarea>
			</div>
			<div class="mb-3">
				<label for="timeToCook" class="form-label">Время приготовления</label>
				<input v-model="timeToCook" type="number" min="1" max="500" class="form-control" id="timeToCook" placeholder="">
			</div>
			<button type="submit" class="btn btn-outline-primary">Добавить</button>
		</form>
		<hr>
		<h2>Блюда</h2>
		<p class="text-muted">Количество блюд на данный момент: {{ dishCount }}</p>
		<div class="row row-cols-1 row-cols-md-2 row-cols-xl-4 g-3">
			<div class="col" v-for="dish in dishes">
			<div class="card" style="width: 18rem;">
				<img :src="dish.image" class="card-img-top" alt="...">
				<div class="card-body">
					<h5 class="card-title">{{ dish.title }}</h5>
					<!-- dropdown? -->
					<p class="card-text">{{ dish.preparation }}</p>
					<a class="btn btn-primary" @click="cooking(dish.id)">Готовить</a>
					<hr>
					<p class="card-title text-muted"> Время приготовления: {{ dish.timeToCook }} минут{{ minuteEnding(dish.timeToCook) }}</p>
				</div>
			</div>
		</div>
	</div>
	</div>
	<hr>
	<h2>В готовке!</h2>
	<div class="container">
		<p class="text-muted">Количество блюд в готовке: {{ dishReadyCount }}</p>
		<div class="row row-cols-1 row-cols-md-2 row-cols-xl-4 g-3">
			<div class="col" v-for="cook in cooked">
			<div class="card" style="width: 18rem;">
				<img :src="cook.image" class="card-img-top" alt="food_image">
				<span class="badge text-bg-warning" v-if="cook.isCooked">ГОТОВО</span>
				<div class="card-body">
					<h5 class="card-title">{{ cook.title }}</h5>
					<hr>
					<p class="card-title text-muted">Время до приготовления: 
						{{ cook.timeToCook - cook.preparingTime }}/{{ cook.timeToCook }} минут{{ minuteEnding(cook.timeToCook - cook.preparingTime)
						 }}</p>
				</div>
			</div>
		</div>
		</div>
	</div>
</template>

<style>
.card {
	margin: 10 auto;
	float: none;
	margin-bottom: 10px;
	background-color: #c9ada7;
}
.card:hover {
	border-color: #22223b;
	transition: 800ms;
}

h2 {
	text-align: center;
}
body {
	background-color: #f2e9e4;
}

</style>
