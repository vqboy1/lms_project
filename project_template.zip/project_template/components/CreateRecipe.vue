<script>
export default {
	data() {
		return {
			title: '',
			preparation: '',
			image: '',
			timeToCook: 10
		};
	},

	mounted() {
		this.loadDishes()
	},

	methods: {
		async createDish() {
			await axios.post('/dishes', {
				title: this.title,
				preparation: this.preparation,
				timeToCook: this.timeToCook,
				image: this.image
			});
			this.loadDishes();
		},
	},
};
</script>

<template>
	<br>
		<form @submit.prevent="createDish" class="mb-3">
			<div class="mb-3">   
				<label for="title" class="form-label">Название рецепта</label>
				<input v-model="title" type="text" class="form-control" id="title" placeholder="Пицца с ананасами">
			</div>
			<div class="mb-3">
				<label for="img" class="form-label">Изображение блюда</label>
				<input v-model="image" type="text" class="form-control" id="img" placeholder="">
			</div>
			<div class="mb-3">
				<label for="preparation" class="form-label">Рецепт</label>
				<textarea v-model="preparation" class="form-control" id="preparation" rows="3" placeholder="Положите ананас на пиццу. Вуаля!"></textarea>
			</div>
			<div class="mb-3">
				<label for="timeToCook" class="form-label">Время приготовления</label>
				<input v-model="timeToCook" type="number" min="1" max="500" class="form-control" id="timeToCook" placeholder="">
			</div>
			<button type="submit" class="btn btn-outline-primary">Добавить</button>
		</form>
</template>

<style>
</style>
